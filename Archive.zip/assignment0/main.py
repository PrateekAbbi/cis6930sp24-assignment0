import argparse
import urllib.request
import certifi
import ssl
import sqlite3
import fitz
import os
from datetime import datetime

def checkdatetime(str):
    try:
        datetime.strptime(str, "%d/%m/%Y %H:%M")
        return True
    except ValueError:
        return False

def fetchincidents(url):         
    headers = {'User-Agent': "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"}

    context = ssl.create_default_context(cafile=certifi.where())             
    data = urllib.request.urlopen(urllib.request.Request(url, headers=headers), context=context).read()

    with open('temp.pdf', 'wb') as f:
        f.write(data)


def extractincidents():
    doc = fitz.open("./temp.pdf")

    all_text = ""
    for page in doc:
        all_text += page.get_text()

    doc.close()

    lines = all_text.split('\n')

    for i in range(5):
        if len(lines) > 0:
            lines.pop(0)

    if (len(lines) > 0 and lines[-1] == ""):
        lines.pop()
    
    if (len(lines) > 0 and ":" in lines[-1] and "/" in lines[-1]):
        lines.pop()

    date_times, incident_numbers, locations, natures, incident_oris = [], [], [], [], []

    for i in range(0, len(lines)):
        if 'Date / Time' in lines[i]: 
            continue

        if i + 4 < len(lines) and '/' in lines[i] and ':' in lines[i]:
            date_times.append(lines[i].strip())
            incident_numbers.append(lines[i + 1].strip())
            locations.append(lines[i + 2].strip())
            if checkdatetime(lines[i + 3].strip()):
                natures.append("prateek")
            else:
                if lines[i + 3].strip() == "RAMP":
                    natures.append(lines[i+4].strip())
                else:
                    natures.append(lines[i + 3].strip())
            incident_oris.append(lines[i + 4].strip())

    data = {
        'Date/Time': date_times,
        'Incident Number': incident_numbers,
        'Location': locations,
        'Nature': natures,
        'Incident ORI': incident_oris 
    }

    return data


def createdb(db):
    try:
        con = sqlite3.connect(f"{db}")
        cur = con.cursor()
        cur.execute(
            '''
            CREATE TABLE incidents (
                incident_time TEXT,
                incident_number TEXT,
                incident_location TEXT,
                nature TEXT,
                incident_ori TEXT
            )
            '''
        )
        return con
    except sqlite3.OperationalError as e:
        print("Invalid Database String")
        return e


def populatedb(db, data):
    cur = db.cursor()
    cur.execute("DELETE FROM incidents")
    n = len(data["Date/Time"])

    for i in range(n):
        cur.execute(
            '''
            INSERT INTO incidents (incident_time, incident_number, incident_location, nature, incident_ori)
            VALUES (?, ?, ?, ?, ?)
            ''',
            (data['Date/Time'][i], data['Incident Number'][i], data['Location'][i], data['Nature'][i], data['Incident ORI'][i])
        )

    db.commit()
    os.remove("temp.pdf")


def status(db):
    cur = db.cursor()
    query = '''
        SELECT nature, COUNT(*) AS count
        FROM incidents
        GROUP BY nature
        ORDER BY count DESC, nature ASC
    '''

    cur.execute(query)
    output = ""
    for row in cur.fetchall():
        if (row[0] == "prateek"):
            output += ""+"|"+str(row[1]) + "\n"
        else:    
            output += row[0] + "|" + str(row[1]) + "\n"

    cur.execute("DROP TABLE incidents")

    return output


def main(url):
    fetchincidents(url)

    incidents = extractincidents()

    # Create new database
    db = createdb("resources/normanpd.db")
	
    # Insert data
    populatedb(db, incidents)
	
    # Print incident counts
    data = status(db)

    return data


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--incidents", type=str, required=True, 
                         help="Incident summary url.")
     
    args = parser.parse_args()
    if args.incidents:
        print(main(args.incidents))